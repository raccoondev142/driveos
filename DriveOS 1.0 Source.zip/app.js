let cdate = new Date();
let hours = cdate.getHours();
let mins = cdate.getMinutes();
function webbrowser() {
    location.href = "webbrowser.html";
}

function go(url) {
    if (document.getElementById("prefix").value != "none") {
        document.getElementById("web").src = document.getElementById("prefix").value + url;
    }
    else {
        document.getElementById("web").src = url;
    }
}

function maps() {
    location.href = "maps.html";
}

function mapsnav() {
    if (document.getElementById("mapsnav").value == "") {
        document.getElementById('error').style.display = 'block';
    }
    else {
        document.getElementById("maps").src = "https://www.google.com/maps/embed/v1/place?key=AIzaSyD3s9EsTRca5-acWjANwOB0F23pnkTc9Gc&q=" + document.getElementById("mapsnav").value;
    }
}

function info() {
    location.href = "about.html";
}

function launchapplet() {
    location.href = "applet.html";
}

function openshutdown() {
    document.getElementById("shutdown-popup").style.display = "block";
}

function closeshutdown() {
    document.getElementById("shutdown-popup").style.display = "none";
}

function shutdown() {
    document.getElementById("shutdown-popup").style.display = "none";
    setTimeout(off, 1000);
}

function off() {
    //Turns the screen off
    document.getElementById("off").style.display = "block";
}